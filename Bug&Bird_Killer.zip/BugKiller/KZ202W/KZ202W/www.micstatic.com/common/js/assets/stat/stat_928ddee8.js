var statMonitor=function(n){var t=function n(t,i,o,r,u){};t.send=function(){};return t}.call(this,window.jQuery);
//# sourceMappingURL=../../../../__sources__/common/js/assets/stat/stat_928ddee8.js.map
